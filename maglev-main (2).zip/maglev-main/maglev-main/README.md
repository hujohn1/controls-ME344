# MagLev

## Version
Fall 2026

## Relevant Files
- Procedure: https://mems-teach-labs.pages.oit.duke.edu/controls-labs/site/ 
- Box Folder (requires admin access): https://duke.app.box.com/folder/217014793513

## Requirements
### Software
LabVIEW and DAQmx (2022 Q3 and newer)

### Hardware
- PCI-6221 or equivalent
  - Need a PCI/PCIe card if using a multifunction DAQ (USB will not work)
- an RT system, such as a cRIO or PXI will also work

### Supplies (per station)
- 1 x Maglev Unit
- 2 x BNC cables

### Code
See files under the ```source``` folder:
- ```MagLev Project```: is the LabVIEW project
- ```MagLev```: is the Main. __Edit this file!!__
- ```Generate Setpoint```: is a subVI that generates the setpoint. Just drag and drop this VI into your Main. You should __not__ edit this file.
- ```maglev_VIA.viancfg```: is the VI Analyzer Test file

### Steps to Connect MagLev:
1. Grab one of the banana or BNC plugs/cable sets inside of the MagLev Unit. Connect the positive end to Measured Value and the negative terminal to GND
2. Grab a BNC Cable. Connect it from Analog Input 0 (AIO/ADC0) to the banana or BNC plug connected to Measured Value
3. Grab the other banana/BNC plug and cable set and connect the positive terminal to Drive IP. Connect the negative terminal to GND.
4. Grab a BNC cable and connect from Analog Output 0 (DAC0) to the banana/BNC plug connected to Drive IP

# Getting Started
Clone this repository, or download as a zip. If downloaded as a zip, be sure you unzip the folder, and that all of the files are in the same directory, so all dependencies can be loaded.

Open ```MagLev Project.lvproj```. Inside of the project, open ```MagLev.vi```. Add your code to the block diagram and user interface to the front panel of this VI to complete the project!

# VI Analyzer Tests
## About
As part of their presentation, groups will be required to run the VI Analyzer test and any failed tests will result in docked points as part of their *LabVIEW Code Analysis* score. Groups are encouraged to run the VI Analyzer test before their presentation so they have an opportunity to correct any errors. 

VI Analyzer is a static code analysis tool. A test config file (```maglev_VIA.viancfg```) has been configured for this project to score each group's final code as part of the grade. These tests are consistent with VI Analyzer tests for LabVIEW style best practices and code readability that would be part of the grading critera for a LabVIEW certification exam.

A complete list of the critera can be found in the VI Analyzer window once the config file has been loaded. Here are a few parameters that the test covers:
- ```MagLev.vi``` should have a VI Description and a non-default VI icon.
- Any controls or indicators on the front panel must have descriptions and tip strips.
- The block diagram should avoid unncessary wire bends and wires that do not flow from left to right.
- The block diagram should fit within 1024 x 768 resolution.
- The block diagram should minimize crossing wires or wires under objects.
- Avoid duplicate labels, clipped text, overlapping controls.
- Avoid hidden objects or tunnels.
- Eliminate unused code or broken VIs.

The VI Analyzer tests do not specifically test for this, but you should use consistent Control styles for all of your front panel elements.

# Running the tests
In the LabVIEW menu bar, select *Tools>>VI Analyzer>>Analyze VIs...*

In the VI Analyzer window, select *Load a previously saved analysis configuration file*. Then, press Next. In the file window, select ```maglev_VIA.viancfg```. Make sure that ```MagLev.vi``` is listed under *Items to Analyze*. Then, press Next. On the next page, press Analyze. When the test is complete, the *Test Results* window will list any failed tests.

## Instructor Notes
There are also versions using a cRIO, one using the FPGA and another using just the RT system. See Eric for access to this.
